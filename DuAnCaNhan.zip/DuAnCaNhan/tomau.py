import sys
import random
import math
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QStatusBar, QGraphicsView, QGraphicsScene,
    QGraphicsEllipseItem, QGraphicsLineItem, QGraphicsTextItem, QColorDialog,
    QListWidget, QListWidgetItem, QFrame, QComboBox, QTextEdit,
    QMessageBox  # <-- Đã thêm QMessageBox vào đây để sửa lỗi
)
from PyQt6.QtGui import QBrush, QPen, QColor, QFont
from PyQt6.QtCore import Qt, QTimer, QPointF

# ----------------------------------------------------------------------
# DỮ LIỆU BẢN ĐỒ (Đồ thị các vùng liền kề - Bản đồ Úc)
# ----------------------------------------------------------------------
REGIONS = ["WA", "NT", "SA", "Q", "NSW", "V", "T"]
EDGES = [
    ("WA", "NT"), ("WA", "SA"), ("NT", "SA"), ("NT", "Q"),
    ("SA", "Q"), ("SA", "NSW"), ("SA", "V"), ("Q", "NSW"),
    ("NSW", "V"),
]
POSITIONS = {
    "WA": (-260, -20), "NT": (-100, -140), "SA": (-60, 20),
    "Q": (140, -140), "NSW": (170, 30), "V": (110, 140), "T": (170, 220),
}

DEFAULT_PALETTE = [QColor("#FF5E7E"), QColor("#5ECBFF"),
                   QColor("#FFD166"), QColor("#7EE787")]

def build_neighbors():
    neigh = {r: set() for r in REGIONS}
    for a, b in EDGES:
        neigh[a].add(b)
        neigh[b].add(a)
    return neigh

NEIGHBORS = build_neighbors()

# ----------------------------------------------------------------------
#  BẢNG MÀU GIAO DIỆN SÁNG (LIGHT MODERN THEME)
# ----------------------------------------------------------------------
COLOR_BG = "#F4F6F9"         
COLOR_CARD = "#FFFFFF"       
COLOR_EDGE = "#CBD5E1"       
COLOR_NODE_EMPTY = "#E2E8F0" 
COLOR_TEXT = "#2B2D42"       
COLOR_HINT = "#FFC107"       

# ----------------------------------------------------------------------
#  CÁC THUẬT TOÁN CSP (TRẢ VỀ DANH SÁCH BƯỚC ĐỂ ANIMATION)
# ----------------------------------------------------------------------
def backtracking_steps(num_colors):
    steps = []
    assignment = {}

    def consistent(region, color):
        return all(assignment.get(n) != color for n in NEIGHBORS[region])

    def backtrack(index):
        if index == len(REGIONS):
            return True
        region = REGIONS[index]
        for color in range(num_colors):
            if consistent(region, color):
                assignment[region] = color
                steps.append((dict(assignment), f"Gán {region} = Màu {color+1}"))
                if backtrack(index + 1):
                    return True
                del assignment[region]
                steps.append((dict(assignment), f"Quay lui (Backtrack) khỏi {region}"))
        return False

    ok = backtrack(0)
    return steps, ok


def ac3_then_backtracking(num_colors):
    steps = []
    domains = {r: set(range(num_colors)) for r in REGIONS}

    def revise(xi, xj):
        revised = False
        to_remove = set()
        for vx in domains[xi]:
            if not any(vx != vy for vy in domains[xj]):
                to_remove.add(vx)
        if to_remove:
            domains[xi] -= to_remove
            revised = True
        return revised

    queue = [(a, b) for a, b in EDGES] + [(b, a) for a, b in EDGES]
    while queue:
        xi, xj = queue.pop(0)
        if revise(xi, xj):
            steps.append(({r: None for r in REGIONS},
                           f"AC-3 lọc miền {xi} (do {xj}): {sorted(domains[xi])}"))
            if not domains[xi]:
                steps.append(({r: None for r in REGIONS}, "AC-3: Miền rỗng -> Vô nghiệm"))
                return steps, False
            for xk in NEIGHBORS[xi] - {xj}:
                queue.append((xk, xi))

    assignment = {}

    def consistent(region, color):
        return all(assignment.get(n) != color for n in NEIGHBORS[region])

    def backtrack(index):
        if index == len(REGIONS):
            return True
        region = REGIONS[index]
        for color in sorted(domains[region]):
            if consistent(region, color):
                assignment[region] = color
                steps.append((dict(assignment), f"(Sau AC-3) Gán {region} = Màu {color+1}"))
                if backtrack(index + 1):
                    return True
                del assignment[region]
                steps.append((dict(assignment), f"Quay lui khỏi {region}"))
        return False

    ok = backtrack(0)
    return steps, ok


def min_conflicts_steps(num_colors, max_steps=200):
    steps = []
    assignment = {r: random.randrange(num_colors) for r in REGIONS}
    steps.append((dict(assignment), "Khởi tạo ngẫu nhiên vị trí màu"))

    def conflicts(region, color, assign):
        return sum(1 for n in NEIGHBORS[region] if assign.get(n) == color)

    for i in range(max_steps):
        conflicted = [r for r in REGIONS if conflicts(r, assignment[r], assignment) > 0]
        if not conflicted:
            steps.append((dict(assignment), "Đã giải xong (0 xung đột) 🎉"))
            return steps, True
        region = random.choice(conflicted)
        best_colors, best_conf = [], math.inf
        for color in range(num_colors):
            c = conflicts(region, color, assignment)
            if c < best_conf:
                best_conf, best_colors = c, [color]
            elif c == best_conf:
                best_colors.append(color)
        assignment[region] = random.choice(best_colors)
        steps.append((dict(assignment), f"Đổi {region} -> Màu {assignment[region]+1}"))

    steps.append((dict(assignment), "Đạt giới hạn bước giải bài toán"))
    return steps, False


# ----------------------------------------------------------------------
#  GIAO DIỆN ĐỒ THỊ BẢN ĐỒ
# ----------------------------------------------------------------------
class MapScene(QGraphicsScene):
    def __init__(self):
        super().__init__()
        self.setSceneRect(-320, -220, 640, 460)
        self.node_items = {}
        self.text_items = {}
        self._draw_edges()
        self._draw_nodes()

    def _draw_edges(self):
        pen = QPen(QColor(COLOR_EDGE))
        pen.setWidth(2)
        for a, b in EDGES:
            xa, ya = POSITIONS[a]
            xb, yb = POSITIONS[b]
            line = QGraphicsLineItem(xa, ya, xb, yb)
            line.setPen(pen)
            line.setZValue(-1)
            self.addItem(line)

    def _draw_nodes(self):
        radius = 28
        for r in REGIONS:
            x, y = POSITIONS[r]
            ellipse = QGraphicsEllipseItem(x - radius, y - radius, radius * 2, radius * 2)
            ellipse.setBrush(QBrush(QColor(COLOR_NODE_EMPTY)))
            ellipse.setPen(QPen(QColor("#CBD5E1"), 1.5))
            self.addItem(ellipse)
            self.node_items[r] = ellipse

            text = QGraphicsTextItem(r)
            text.setDefaultTextColor(QColor(COLOR_TEXT))
            font = QFont("Arial", 10, QFont.Weight.Bold)
            text.setFont(font)
            br = text.boundingRect()
            text.setPos(x - br.width() / 2, y - br.height() / 2)
            self.addItem(text)
            self.text_items[r] = text

    def apply_assignment(self, assignment, palette):
        for r in REGIONS:
            color_idx = assignment.get(r)
            if color_idx is None:
                self.node_items[r].setBrush(QBrush(QColor(COLOR_NODE_EMPTY)))
                self.node_items[r].setPen(QPen(QColor("#CBD5E1"), 1.5))
            else:
                col = palette[color_idx % len(palette)]
                self.node_items[r].setBrush(QBrush(col))
                self.node_items[r].setPen(QPen(QColor("#94A3B8"), 1.5))

    def highlight_node(self, region):
        self.node_items[region].setBrush(QBrush(QColor(COLOR_HINT)))
        self.node_items[region].setPen(QPen(QColor("#D69E2E"), 3))


class ColorPaletteWidget(QWidget):
    def __init__(self, palette, on_change):
        super().__init__()
        self.palette = palette
        self.on_change = on_change
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        self.buttons = []
        for i, color in enumerate(self.palette):
            b = QPushButton(f"Màu {i+1}")
            b.setStyleSheet(self._style_for(color))
            b.clicked.connect(lambda _, idx=i: self.pick_color(idx))
            layout.addWidget(b)
            self.buttons.append(b)

    def _style_for(self, color):
        return (f"QPushButton{{background:{color.name()}; color:#10131c; border:none;"
                f"font-weight:bold; padding:6px; border-radius:6px; font-size:11px;}}")

    def pick_color(self, idx):
        color = QColorDialog.getColor(self.palette[idx], self, "Chọn màu mới")
        if color.isValid():
            self.palette[idx] = color
            self.buttons[idx].setStyleSheet(self._style_for(color))
            self.on_change()


# ----------------------------------------------------------------------
#  CẤU TRÚC GIAO DIỆN SIDEBAR CHÍNH
# ----------------------------------------------------------------------
class MapColoringWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Tô Màu Bản Đồ AI - Trực Quan Hóa Bài Toán CSP")
        self.setStyleSheet(f"background-color:{COLOR_BG}; color:{COLOR_TEXT};")
        self.setMinimumSize(1000, 640)

        self.palette = list(DEFAULT_PALETTE)
        self.num_colors = len(self.palette)
        self.algorithm = "Backtracking"

        self.steps = []
        self.step_index = 0
        self.running = False
        self.paused = False

        self.timer = QTimer()
        self.timer.setInterval(450)
        self.timer.timeout.connect(self._advance_step)

        self._build_main_layout()
        self.on_reset()

    def _build_main_layout(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(15)

        # 1. SIDEBAR DỌC TRÁI
        sidebar = QFrame()
        sidebar.setFixedWidth(220)
        sidebar.setStyleSheet(
            f"background-color: {COLOR_CARD}; border-radius: 12px; border: 1px solid #E2E8F0;"
        )
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(15, 20, 15, 20)
        side_layout.setSpacing(12)

        brand_label = QLabel("TÔ MÀU CSP MENU")
        brand_label.setFont(QFont("Arial", 13, QFont.Weight.Bold))
        brand_label.setStyleSheet("color: #1D3557; border: none; margin-bottom: 10px;")
        brand_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        side_layout.addWidget(brand_label)

        self.btn_start = QPushButton("▶  Bắt Đầu")
        self.btn_pause = QPushButton("⏸  Tạm Dừng")
        self.btn_stop = QPushButton("⏹  Dừng Chạy")
        self.btn_reset = QPushButton("⟲  Làm Mới")
        
        btn_style = (
            f"QPushButton {{ background-color: #F1F5F9; color: {COLOR_TEXT}; border: none; "
            f"padding: 10px; text-align: left; font-size: 13px; font-weight: 600; border-radius: 8px; }}"
            f"QPushButton:hover {{ background-color: #E2E8F0; }}"
        )
        
        for btn, slot in [(self.btn_start, self.on_start), (self.btn_pause, self.on_pause),
                          (self.btn_stop, self.on_stop), (self.btn_reset, self.on_reset)]:
            btn.setStyleSheet(btn_style)
            btn.clicked.connect(slot)
            side_layout.addWidget(btn)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("color: #E2E8F0; border: none;")
        side_layout.addWidget(line)

        algo_title = QLabel("Chọn thuật toán:")
        algo_title.setStyleSheet("border: none; font-weight: bold; color: #64748B;")
        side_layout.addWidget(algo_title)

        self.combo_algo = QComboBox()
        self.combo_algo.addItems(["Backtracking", "AC-3 + Backtracking", "Min-Conflicts"])
        self.combo_algo.setStyleSheet(
            "QComboBox { padding: 6px; border: 1px solid #CBD5E1; border-radius: 6px; background: white; }"
        )
        self.combo_algo.currentTextChanged.connect(self.set_algorithm)
        side_layout.addWidget(self.combo_algo)

        side_layout.addStretch()

        self.btn_hint = QPushButton("💡  AI Phân Tích Đồ Thị")
        self.btn_hint.setStyleSheet(
            f"QPushButton {{ background-color: {COLOR_HINT}; color: #000000; border: none; "
            f"padding: 12px; font-size: 13px; font-weight: bold; border-radius: 8px; }}"
            f"QPushButton:hover {{ background-color: #E6A100; }}"
        )
        self.btn_hint.clicked.connect(self.on_request_hint)
        side_layout.addWidget(self.btn_hint)

        main_layout.addWidget(sidebar)

        # 2. KHU VỰC ĐỒ THỊ GIỮA
        canvas_area = QWidget()
        canvas_layout = QVBoxLayout(canvas_area)
        canvas_layout.setContentsMargins(0, 0, 0, 0)
        canvas_layout.setSpacing(10)

        header_widget = QFrame()
        header_widget.setStyleSheet(f"background-color: {COLOR_CARD}; border-radius: 10px; border: 1px solid #E2E8F0;")
        header_layout = QHBoxLayout(header_widget)
        
        self.lbl_algo = QLabel(f"Thuật toán: <b>{self.algorithm}</b>")
        self.lbl_step_info = QLabel("Bước: -")
        self.lbl_algo.setStyleSheet("border:none; font-size:13px;")
        self.lbl_step_info.setStyleSheet("border:none; font-size:13px; font-weight:bold;")
        
        header_layout.addWidget(self.lbl_algo)
        header_layout.addStretch()
        header_layout.addWidget(self.lbl_step_info)
        canvas_layout.addWidget(header_widget)

        self.scene = MapScene()
        self.view = QGraphicsView(self.scene)
        self.view.setStyleSheet(f"background:{COLOR_CARD}; border-radius:12px; border: 1px solid #E2E8F0;")
        self.view.setRenderHint(self.view.renderHints())
        canvas_layout.addWidget(self.view)
        
        main_layout.addWidget(canvas_area, stretch=2)

        # 3. RIGHT PANEL
        right_panel = QFrame()
        right_panel.setFixedWidth(250)
        right_panel.setStyleSheet(
            f"background-color: {COLOR_CARD}; border-radius: 12px; border: 1px solid #E2E8F0;"
        )
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(12, 15, 12, 15)

        palette_title = QLabel("🎨 Bảng Màu Đầu Vào")
        palette_title.setStyleSheet("font-weight: bold; color:#475569;")
        right_layout.addWidget(palette_title)
        
        self.palette_widget = ColorPaletteWidget(self.palette, self.on_palette_changed)
        right_layout.addWidget(self.palette_widget)

        log_title = QLabel("📜 Nhật Ký Tiến Trình")
        log_title.setStyleSheet("font-weight: bold; color:#475569; margin-top: 10px;")
        right_layout.addWidget(log_title)
        
        self.log_list = QListWidget()
        self.log_list.setStyleSheet("border: 1px solid #E2E8F0; border-radius: 6px; background:#F8FAFC; font-size:11px;")
        right_layout.addWidget(self.log_list, stretch=1)

        analysis_title = QLabel("🤖 Phân Tích Cấu Trúc CSP")
        analysis_title.setStyleSheet("font-weight: bold; color:#475569; margin-top: 5px;")
        right_layout.addWidget(analysis_title)

        self.txt_analysis = QTextEdit()
        self.txt_analysis.setReadOnly(True)
        self.txt_analysis.setStyleSheet("border: 1px solid #E2E8F0; border-radius: 6px; background:#F8FAFC; font-size:12px;")
        right_layout.addWidget(self.txt_analysis, stretch=1)

        main_layout.addWidget(right_panel)

        self.setStatusBar(QStatusBar())
        self.statusBar().setStyleSheet("background: white; border-top: 1px solid #E2E8F0;")

    def set_algorithm(self, name):
        self.algorithm = name
        self.lbl_algo.setText(f"Thuật toán: <b>{name}</b>")
        self.statusBar().showMessage(f"Đã chuyển sang cấu hình thuật toán: {name}")

    def on_palette_changed(self):
        if self.steps and self.step_index > 0:
            assignment, _ = self.steps[min(self.step_index - 1, len(self.steps) - 1)]
            self.scene.apply_assignment(assignment, self.palette)
        else:
            self.scene.apply_assignment({r: None for r in REGIONS}, self.palette)

    def on_start(self):
        if not self.running:
            self._compute_steps()
            self.step_index = 0
            self.log_list.clear()
        self.running = True
        self.paused = False
        self.timer.start()
        self.statusBar().showMessage(f"Đang thực thi mô phỏng {self.algorithm}...")

    def on_pause(self):
        if not self.running: return
        self.paused = not self.paused
        if self.paused:
            self.timer.stop()
            self.statusBar().showMessage("Mô phỏng tạm dừng.")
        else:
            self.timer.start()
            self.statusBar().showMessage("Tiếp tục tiến trình.")

    def on_stop(self):
        self.running = False
        self.paused = False
        self.timer.stop()
        self.statusBar().showMessage("Đã dừng chạy thuật toán.")

    def on_reset(self):
        self.on_stop()
        self.steps = []
        self.step_index = 0
        self.log_list.clear()
        self.txt_analysis.clear()
        self.txt_analysis.setText("Hệ thống phân tích CSP đã sẵn sàng.\nNhấn 'Bắt Đầu' để quan sát thuật toán.")
        self.lbl_step_info.setText("Bước: -")
        self.scene.apply_assignment({r: None for r in REGIONS}, self.palette)
        self.statusBar().showMessage("Đã đưa bản đồ về trạng thái trống ban đầu.")

    def _compute_steps(self):
        if self.algorithm == "Backtracking":
            self.steps, ok = backtracking_steps(self.num_colors)
        elif self.algorithm == "AC-3 + Backtracking":
            self.steps, ok = ac3_then_backtracking(self.num_colors)
        else:
            self.steps, ok = min_conflicts_steps(self.num_colors)
        
        status_str = "Thành công" if ok else "Không tìm thấy nghiệm"
        self.lbl_algo.setText(f"Thuật toán: <b>{self.algorithm}</b> ({status_str})")

    def _advance_step(self):
        if self.step_index >= len(self.steps):
            self.timer.stop()
            self.running = False
            self.statusBar().showMessage("Thuật toán đã chạy xong cấu hình kết quả hoàn tất!")
            
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Hoàn tất tiến trình")
            msg_box.setText("<h3>Hệ thống đã hoàn thành việc tô màu bản đồ!</h3>")
            msg_box.setIcon(QMessageBox.Icon.Information)
            msg_box.setStyleSheet(
                "QMessageBox { background-color: #FFFFFF; }"
                "QPushButton { background-color: #1D3557; color: white; padding: 5px 12px; border-radius: 4px; font-weight: bold; }"
            )
            msg_box.exec()
            return

        assignment, desc = self.steps[self.step_index]
        self.scene.apply_assignment(assignment, self.palette)
        self.lbl_step_info.setText(f"Bước {self.step_index + 1}/{len(self.steps)}")
        
        item = QListWidgetItem(f"Bước {self.step_index + 1}: {desc}")
        self.log_list.addItem(item)
        self.log_list.scrollToBottom()
        self.step_index += 1

    def on_request_hint(self):
        max_degree = -1
        target_region = None
        
        for r in REGIONS:
            degree = len(NEIGHBORS[r])
            if degree > max_degree:
                max_degree = degree
                target_region = r

        if target_region:
            self.on_reset() 
            self.scene.highlight_node(target_region)
            
            neighbors_list = ", ".join(list(NEIGHBORS[target_region]))
            analysis_text = (
                f"💡 PHÂN TÍCH CHIỂN THUẬT AI:\n"
                f"Vùng trọng tâm hệ thống là: [{target_region}].\n\n"
                f"Lý do phân tích ràng buộc:\n"
                f"- Bang này có tới {max_degree} liên kết chung liền kề bao gồm: ({neighbors_list}).\n"
                f"- Theo lý thuyết cây CSP (Heuristic MRV/Degree), bạn bắt buộc phải ưu tiên chọn màu cho vùng [{target_region}] trước để thu hẹp không gian tìm kiếm, tránh lỗi quay lui (Backtracking) quá nhiều lần."
            )
            self.txt_analysis.setText(analysis_text)
            self.statusBar().showMessage(f"AI đã đánh dấu vùng trọng yếu cần xử lý ưu tiên: {target_region}")


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    win = MapColoringWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()