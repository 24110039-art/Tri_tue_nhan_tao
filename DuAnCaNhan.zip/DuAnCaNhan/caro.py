import sys
import math
import time
import random
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QGridLayout, QPushButton,
    QLabel, QVBoxLayout, QHBoxLayout, QStatusBar, QMessageBox,
    QFrame, QComboBox, QListWidget, QTextEdit
)
from PyQt6.QtGui import QFont, QColor, QPalette
from PyQt6.QtCore import Qt, QTimer

BOARD_SIZE = 12          
WIN_LEN = 5
EMPTY, HUMAN, AI = 0, 1, 2
SEARCH_DEPTH = 2          

DIRECTIONS = [(1, 0), (0, 1), (1, 1), (1, -1)]

# ----------------------------------------------------------------------
#  BẢNG MÀU GIAO DIỆN SÁNG (LIGHT MODERN THEME)
# ----------------------------------------------------------------------
COLOR_BG = "#F4F6F9"         # Nền chính xám nhẹ sang trọng
COLOR_CARD = "#FFFFFF"       # Nền các khung chức năng trắng tinh khôi
COLOR_CELL = "#E9ECEF"       # Ô cờ trống
COLOR_CELL_HOVER = "#DEE2E6" # Ô cờ khi di chuột qua
COLOR_HUMAN = "#E63946"      # Quân X màu Đỏ Coral rực rỡ
COLOR_AI = "#1D3557"         # Quân O màu Xanh Navy lịch lãm
COLOR_HINT = "#FFC107"       # Màu Vàng Hổ Phách khi gợi ý nước đi
COLOR_TEXT = "#2B2D42"       # Màu chữ chính chữ tối thanh lịch

def to_notation(r, c):
    """Chuyển tọa độ ma trận thành ký hiệu bàn cờ (Ví dụ: Row 0, Col 5 -> F1)"""
    return f"{chr(65 + c)}{r + 1}"

# ----------------------------------------------------------------------
#  LOGIC CỜ CARO
# ----------------------------------------------------------------------
class CaroEngine:
    def __init__(self, size=BOARD_SIZE):
        self.size = size
        self.board = [[EMPTY] * size for _ in range(size)]

    def reset(self):
        self.board = [[EMPTY] * self.size for _ in range(self.size)]

    def in_bounds(self, r, c):
        return 0 <= r < self.size and 0 <= c < self.size

    def check_win(self, player):
        b = self.board
        for r in range(self.size):
            for c in range(self.size):
                if b[r][c] != player:
                    continue
                for dr, dc in DIRECTIONS:
                    cnt = 0
                    rr, cc = r, c
                    while self.in_bounds(rr, cc) and b[rr][cc] == player:
                        cnt += 1
                        rr += dr
                        cc += dc
                    if cnt >= WIN_LEN:
                        return True
        return False

    def is_full(self):
        return all(self.board[r][c] != EMPTY
                   for r in range(self.size) for c in range(self.size))

    def candidate_moves(self, radius=2):
        moves = set()
        has_stone = False
        for r in range(self.size):
            for c in range(self.size):
                if self.board[r][c] != EMPTY:
                    has_stone = True
                    for dr in range(-radius, radius + 1):
                        for dc in range(-radius, radius + 1):
                            rr, cc = r + dr, c + dc
                            if self.in_bounds(rr, cc) and self.board[rr][cc] == EMPTY:
                                moves.add((rr, cc))
        if not has_stone:
            mid = self.size // 2
            return [(mid, mid)]
        return list(moves)

    def evaluate(self):
        return self._score_player(AI) - self._score_player(HUMAN)

    def _score_player(self, player):
        b = self.board
        score = 0
        pattern_score = {5: 100000, 4: 5000, 3: 500, 2: 50, 1: 5}
        for r in range(self.size):
            for c in range(self.size):
                if b[r][c] != player:
                    continue
                for dr, dc in [(1, 0), (0, 1), (1, 1), (1, -1)]:
                    pr, pc = r - dr, c - dc
                    if self.in_bounds(pr, pc) and b[pr][pc] == player:
                        continue  
                    cnt = 0
                    rr, cc = r, c
                    while self.in_bounds(rr, cc) and b[rr][cc] == player:
                        cnt += 1
                        rr += dr
                        cc += dc
                    cnt = min(cnt, 5)
                    score += pattern_score.get(cnt, 0)
        return score

# ----------------------------------------------------------------------
#  CÁC THUẬT TOÁN TÌM KIẾM AI
# ----------------------------------------------------------------------
def minimax(engine, depth, maximizing):
    if depth == 0 or engine.check_win(AI) or engine.check_win(HUMAN) or engine.is_full():
        return engine.evaluate(), None

    moves = engine.candidate_moves()
    best_move = None
    if maximizing:
        best_val = -math.inf
        for (r, c) in moves:
            engine.board[r][c] = AI
            val, _ = minimax(engine, depth - 1, False)
            engine.board[r][c] = EMPTY
            if val > best_val:
                best_val, best_move = val, (r, c)
        return best_val, best_move
    else:
        best_val = math.inf
        for (r, c) in moves:
            engine.board[r][c] = HUMAN
            val, _ = minimax(engine, depth - 1, True)
            engine.board[r][c] = EMPTY
            if val < best_val:
                best_val, best_move = val, (r, c)
        return best_val, best_move

def alphabeta(engine, depth, alpha, beta, maximizing):
    if depth == 0 or engine.check_win(AI) or engine.check_win(HUMAN) or engine.is_full():
        return engine.evaluate(), None

    moves = engine.candidate_moves()
    best_move = None
    if maximizing:
        best_val = -math.inf
        for (r, c) in moves:
            engine.board[r][c] = AI
            val, _ = alphabeta(engine, depth - 1, alpha, beta, False)
            engine.board[r][c] = EMPTY
            if val > best_val:
                best_val, best_move = val, (r, c)
            alpha = max(alpha, best_val)
            if alpha >= beta:
                break  
        return best_val, best_move
    else:
        best_val = math.inf
        for (r, c) in moves:
            engine.board[r][c] = HUMAN
            val, _ = alphabeta(engine, depth - 1, alpha, beta, True)
            engine.board[r][c] = EMPTY
            if val < best_val:
                best_val, best_move = val, (r, c)
            beta = min(beta, best_val)
            if alpha >= beta:
                break  
        return best_val, best_move

def expectimax(engine, depth, is_ai_turn):
    if depth == 0 or engine.check_win(AI) or engine.check_win(HUMAN) or engine.is_full():
        return engine.evaluate(), None

    moves = engine.candidate_moves()
    best_move = None
    if is_ai_turn:
        best_val = -math.inf
        for (r, c) in moves:
            engine.board[r][c] = AI
            val, _ = expectimax(engine, depth - 1, False)
            engine.board[r][c] = EMPTY
            if val > best_val:
                best_val, best_move = val, (r, c)
        return best_val, best_move
    else:
        total = 0.0
        for (r, c) in moves:
            engine.board[r][c] = HUMAN
            val, _ = expectimax(engine, depth - 1, True)
            engine.board[r][c] = EMPTY
            total += val
        avg = total / len(moves) if moves else 0
        return avg, None

# ----------------------------------------------------------------------
#  GIAO DIỆN Ô CỜ TỐI ƯU
# ----------------------------------------------------------------------
CELL_SIZE = 42

class Cell(QPushButton):
    def __init__(self, r, c, callback):
        super().__init__("")
        self.r, self.c = r, c
        self.setFixedSize(CELL_SIZE, CELL_SIZE)
        self.callback = callback
        self.clicked.connect(self._on_click)
        self.set_style(EMPTY)

    def _on_click(self):
        self.callback(self.r, self.c)

    def set_style(self, state):
        if state == HUMAN:
            self.setText("X")
            self.setStyleSheet(
                f"background:{COLOR_CARD}; color:{COLOR_HUMAN}; font-weight:bold; "
                f"font-size:20px; border:1px solid #CED4DA; border-radius:4px;")
            self.setEnabled(False)
        elif state == AI:
            self.setText("O")
            self.setStyleSheet(
                f"background:{COLOR_CARD}; color:{COLOR_AI}; font-weight:bold; "
                f"font-size:20px; border:1px solid #CED4DA; border-radius:4px;")
            self.setEnabled(False)
        else:
            self.setText("")
            self.setStyleSheet(
                f"QPushButton {{ background:{COLOR_CELL}; border:1px solid #DEE2E6; border-radius:4px; }}"
                f"QPushButton:hover {{ background:{COLOR_CELL_HOVER}; }}")
            self.setEnabled(True)

    def highlight_hint(self):
        """Đánh dấu ô cờ gợi ý chiến thuật"""
        self.setStyleSheet(
            f"background:{COLOR_HINT}; color:#000000; font-weight:bold; "
            f"font-size:20px; border:2px solid #D69E2E; border-radius:4px;")
        self.setText("?")

# ----------------------------------------------------------------------
#  GIAO DIỆN CHÍNH (SIDEBAR TRÁI - BOARD GIỮA - INFO PHẢI)
# ----------------------------------------------------------------------
class CaroWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cờ Caro Trí Tuệ Nhân Tạo AI")
        self.setStyleSheet(f"background-color:{COLOR_BG}; color:{COLOR_TEXT};")
        self.setMinimumSize(980, 640)

        self.engine = CaroEngine()
        self.algorithm = "Alpha-Beta"
        self.running = False     
        self.paused = False
        self.game_over = False
        self.hinted_cell = None  # Lưu ô đang được AI gợi ý để reset lại sau

        self._build_main_layout()
        self.on_reset()

    def _build_main_layout(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(15)

        # ==================================================================
        # 1. THANH MENU DỌC BÊN TRÁI (SIDEBAR NAVIGATION)
        # ==================================================================
        sidebar = QFrame()
        sidebar.setFixedWidth(220)
        sidebar.setStyleSheet(
            f"background-color: {COLOR_CARD}; border-radius: 12px; "
            f"border: 1px solid #E2E8F0;"
        )
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(15, 20, 15, 20)
        side_layout.setSpacing(12)

        # App Brand Title
        brand_label = QLabel("CARO AI MENU")
        brand_label.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        brand_label.setStyleSheet(f"color: {COLOR_AI}; border: none; margin-bottom: 10px;")
        brand_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        side_layout.addWidget(brand_label)

        # Menu Action Buttons
        self.btn_start = QPushButton("▶  Bắt Đầu")
        self.btn_pause = QPushButton("⏸  Tạm Dừng")
        self.btn_stop = QPushButton("⏹  Dừng Chơi")
        self.btn_reset = QPushButton("⟲  Làm Mới")
        
        # Style cho các nút điều hướng dọc
        btn_style = (
            f"QPushButton {{ background-color: #F1F5F9; color: {COLOR_TEXT}; border: none; "
            f"padding: 10px; text-align: left; font-size: 13px; font-weight: 600; border-radius: 8px; }}"
            f"QPushButton:hover {{ background-color: #E2E8F0; }}"
            f"QPushButton:pressed {{ background-color: #CBD5E1; }}"
        )
        
        for btn, slot in [(self.btn_start, self.on_start), (self.btn_pause, self.on_pause),
                          (self.btn_stop, self.on_stop), (self.btn_reset, self.on_reset)]:
            btn.setStyleSheet(btn_style)
            btn.clicked.connect(slot)
            side_layout.addWidget(btn)

        # Khung phân tách thẩm mỹ
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("color: #E2E8F0; border: none;")
        side_layout.addWidget(line)

        # Cài đặt chọn Thuật toán AI
        algo_title = QLabel("Thuật toán AI:")
        algo_title.setStyleSheet("border: none; font-weight: bold; color: #64748B;")
        side_layout.addWidget(algo_title)

        self.combo_algo = QComboBox()
        self.combo_algo.addItems(["Alpha-Beta", "Minimax", "Expectimax"])
        self.combo_algo.setCurrentText("Alpha-Beta")
        self.combo_algo.setStyleSheet(
            "QComboBox { padding: 6px; border: 1px solid #CBD5E1; border-radius: 6px; background: white; }"
        )
        self.combo_algo.currentTextChanged.connect(self.set_algorithm)
        side_layout.addWidget(self.combo_algo)

        side_layout.addStretch()

        # Nút GỢI Ý CỜ AI (HINT SYSTEM)
        self.btn_hint = QPushButton("💡  AI Gợi Ý Nước Đi")
        self.btn_hint.setStyleSheet(
            f"QPushButton {{ background-color: {COLOR_HINT}; color: #000000; border: none; "
            f"padding: 12px; font-size: 13px; font-weight: bold; border-radius: 8px; }}"
            f"QPushButton:hover {{ background-color: #E6A100; }}"
        )
        self.btn_hint.clicked.connect(self.on_request_hint)
        side_layout.addWidget(self.btn_hint)

        main_layout.addWidget(sidebar)

        # ==================================================================
        # 2. KHU VỰC BÀN CỜ Ở GIỮA (MAIN BOARD GAMEPLAY)
        # ==================================================================
        board_area = QWidget()
        board_layout = QVBoxLayout(board_area)
        board_layout.setContentsMargins(0, 0, 0, 0)
        board_layout.setSpacing(10)

        # Header Info Row
        header_widget = QFrame()
        header_widget.setStyleSheet(f"background-color: {COLOR_CARD}; border-radius: 10px; border: 1px solid #E2E8F0;")
        header_layout = QHBoxLayout(header_widget)
        
        self.lbl_algo = QLabel(f"Đang dùng: <b>{self.algorithm}</b>")
        self.lbl_turn = QLabel("Lượt chơi: —")
        self.lbl_algo.setStyleSheet("border:none; font-size:13px;")
        self.lbl_turn.setStyleSheet("border:none; font-size:13px; font-weight:bold;")
        
        header_layout.addWidget(self.lbl_algo)
        header_layout.addStretch()
        header_layout.addWidget(self.lbl_turn)
        board_layout.addWidget(header_widget)

        # Bàn cờ 12x12
        board_frame = QFrame()
        board_frame.setStyleSheet(f"background-color: {COLOR_CARD}; border-radius: 12px; border: 1px solid #E2E8F0;")
        grid = QGridLayout(board_frame)
        grid.setSpacing(4)
        grid.setContentsMargins(12, 12, 12, 12)
        
        self.cells = {}
        for r in range(self.engine.size):
            for c in range(self.engine.size):
                cell = Cell(r, c, self.on_cell_clicked)
                grid.addWidget(cell, r, c)
                self.cells[(r, c)] = cell
                
        board_layout.addWidget(board_frame)
        main_layout.addWidget(board_area, stretch=2)

        # ==================================================================
        # 3. PHÂN TÍCH CHIẾN THUẬT & LỊCH SỬ NƯỚC ĐI (RIGHT PANEL)
        # ==================================================================
        right_panel = QFrame()
        right_panel.setFixedWidth(240)
        right_panel.setStyleSheet(
            f"background-color: {COLOR_CARD}; border-radius: 12px; border: 1px solid #E2E8F0;"
        )
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(12, 15, 12, 15)

        # Widget lịch sử nước đi
        hist_title = QLabel("📜 Lịch Sử Nước Đi")
        hist_title.setStyleSheet("font-weight: bold; color:#475569;")
        right_layout.addWidget(hist_title)
        
        self.list_history = QListWidget()
        self.list_history.setStyleSheet("border: 1px solid #E2E8F0; border-radius: 6px; background:#F8FAFC;")
        right_layout.addWidget(self.list_history)

        # Khung phân tích lỗi & Gợi ý từ AI
        analysis_title = QLabel("🤖 Phân Tích AI")
        analysis_title.setStyleSheet("font-weight: bold; color:#475569; margin-top: 5px;")
        right_layout.addWidget(analysis_title)
        
        self.txt_analysis = QTextEdit()
        self.txt_analysis.setReadOnly(True)
        self.txt_analysis.setStyleSheet("border: 1px solid #E2E8F0; border-radius: 6px; background:#F8FAFC; font-size:12px;")
        right_layout.addWidget(self.txt_analysis, stretch=1)

        main_layout.addWidget(right_panel)

        # Thanh trạng thái dưới cùng
        self.setStatusBar(QStatusBar())
        self.statusBar().setStyleSheet("background: white; border-top: 1px solid #E2E8F0;")

    # ---------------- XỬ LÝ SỰ KIỆN ----------------
    def set_algorithm(self, name):
        self.algorithm = name
        self.lbl_algo.setText(f"Đang dùng: <b>{name}</b>")
        self.statusBar().showMessage(f"Đã chuyển sang thuật toán: {name}")

    def on_start(self):
        if self.game_over:
            self.on_reset()
        self.running = True
        self.paused = False
        self._set_board_enabled(True)
        self.lbl_turn.setText("Lượt: Bạn (X)")
        self.statusBar().showMessage("Trận đấu bắt đầu! Bạn cầm quân X đi trước.")

    def on_pause(self):
        if not self.running: return
        self.paused = not self.paused
        self._set_board_enabled(not self.paused and self.running)
        self.lbl_turn.setText("TẠM DỪNG" if self.paused else "Lượt: Bạn (X)")
        self.statusBar().showMessage("Đã tạm dừng trận đấu." if self.paused else "Tiếp tục ván chơi.")

    def on_stop(self):
        self.running = False
        self._set_board_enabled(False)
        self.statusBar().showMessage("Ván đấu đã bị dừng.")

    def on_reset(self):
        self.engine.reset()
        self.clear_hint()
        for cell in self.cells.values():
            cell.set_style(EMPTY)
        self.running = False
        self.paused = False
        self.game_over = False
        self.list_history.clear()
        self.txt_analysis.clear()
        self.txt_analysis.setText("Hệ thống AI đã sẵn sàng. Nhấn 'Bắt Đầu' để chơi!")
        self.lbl_turn.setText("Lượt: —")
        self.statusBar().showMessage("Đã làm mới hoàn toàn bàn cờ.")

    def _set_board_enabled(self, enabled):
        for (r, c), cell in self.cells.items():
            if self.engine.board[r][c] == EMPTY:
                cell.setEnabled(enabled)

    def clear_hint(self):
        """Xóa nước đi gợi ý cũ nếu người chơi đã đánh hoặc reset"""
        if self.hinted_cell:
            r, c = self.hinted_cell
            if self.engine.board[r][c] == EMPTY:
                self.cells[(r, c)].set_style(EMPTY)
            self.hinted_cell = None

    # ---------------- LOGIC CHƠI CỜ & CẬP NHẬT LỊCH SỬ ----------------
    def on_cell_clicked(self, r, c):
        if not self.running or self.paused or self.game_over: return
        if self.engine.board[r][c] != EMPTY: return

        self.clear_hint()  # Có nước đánh mới thì xóa gợi ý cũ đi

        # Người chơi đánh quân X
        self.engine.board[r][c] = HUMAN
        self.cells[(r, c)].set_style(HUMAN)
        
        # Ghi lịch sử
        notation = to_notation(r, c)
        self.list_history.addItem(f"👤 Bạn: {notation}")
        self.list_history.scrollToBottom()

        if self.engine.check_win(HUMAN):
            self._end_game("Chúc mừng! Bạn (X) đã chiến thắng!")
            return
        if self.engine.is_full():
            self._end_game("Trận đấu hòa! Bàn cờ đã kín chỗ.")
            return

        self.lbl_turn.setText("Lượt: Máy (O) đang tính toán...")
        self._set_board_enabled(False)
        QTimer.singleShot(200, self.ai_move)

    def ai_move(self):
        if not self.running or self.paused or self.game_over: return
        t0 = time.time()
        
        if self.algorithm == "Minimax":
            _, move = minimax(self.engine, SEARCH_DEPTH, True)
        elif self.algorithm == "Alpha-Beta":
            _, move = alphabeta(self.engine, SEARCH_DEPTH, -math.inf, math.inf, True)
        else:
            _, move = expectimax(self.engine, SEARCH_DEPTH, True)
        elapsed = time.time() - t0

        if move is None:
            candidates = self.engine.candidate_moves()
            move = random.choice(candidates) if candidates else None

        if move:
            r, c = move
            self.engine.board[r][c] = AI
            self.cells[(r, c)].set_style(AI)
            
            # Ghi lịch sử cho Máy
            notation = to_notation(r, c)
            self.list_history.addItem(f"🤖 Máy: {notation}")
            self.list_history.scrollToBottom()
            self.txt_analysis.setText(f"Máy đi ô {notation}.\nThời gian nghĩ: {elapsed:.2f} giây.")

        if self.engine.check_win(AI):
            self._end_game("Rất tiếc! Máy (O) đã chiến thắng rồi.")
            return
        if self.engine.is_full():
            self._end_game("Trận đấu hòa!")
            return

        self.lbl_turn.setText("Lượt: Bạn (X)")
        self._set_board_enabled(True)

    # ---------------- TÍNH NĂNG AI PHÂN TÍCH & GỢI Ý (AI HINT) ----------------
    def on_request_hint(self):
        """Khi người chơi bấm nút gợi ý, AI sẽ tìm nước đi tối ưu nhất cho Người"""
        if not self.running or self.paused or self.game_over:
            self.statusBar().showMessage("Hãy bấm Bắt Đầu trận đấu trước khi xin gợi ý!")
            return
        
        self.clear_hint()
        self.statusBar().showMessage("AI đang phân tích thế trận tối ưu cho bạn...")
        
        # Để tìm nước tốt nhất cho Người (HUMAN), ta tìm nước tối thiểu hóa điểm số cục diện (maximizing=False)
        if self.algorithm == "Minimax":
            _, move = minimax(self.engine, SEARCH_DEPTH, False)
        elif self.algorithm == "Alpha-Beta":
            _, move = alphabeta(self.engine, SEARCH_DEPTH, -math.inf, math.inf, False)
        else:
            _, move = expectimax(self.engine, SEARCH_DEPTH, False)

        if move:
            r, c = move
            self.hinted_cell = (r, c)
            self.cells[(r, c)].highlight_hint()  # Làm sáng bừng ô cờ được gợi ý
            
            notation = to_notation(r, c)
            analysis_text = (
                f"💡 GỢI Ý CHIẾN THUẬT AI:\n"
                f"Bạn nên đi vào ô [{notation}].\n\n"
                f"Phân tích lý do:\n"
                f"- Giúp chặn đường tấn công tiềm ẩn của Máy.\n"
                f"- Hoặc mở rộng mạch liên kết chuỗi 5 quân của bạn."
            )
            self.txt_analysis.setText(analysis_text)
            self.statusBar().showMessage(f"AI gợi ý bạn nên đánh vào ô: {notation}")
        else:
            self.txt_analysis.setText("AI chưa tìm ra lối đánh đột phá, hãy thử tự đi một nước!")

    def _end_game(self, message):
        self.game_over = True
        self.running = False
        self._set_board_enabled(False)
        self.lbl_turn.setText("KẾT THÚC VÁN ĐẤU")
        self.statusBar().showMessage(message)
        
        # Custom Hộp thoại thông báo chiến thắng sáng sủa hiện đại
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Kết quả trận đấu")
        msg_box.setText(f"<h3>{message}</h3>")
        msg_box.setIcon(QMessageBox.Icon.Information)
        msg_box.setStyleSheet(
            "QMessageBox { background-color: #FFFFFF; }"
            "QPushButton { background-color: #1D3557; color: white; padding: 6px 15px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #457B9D; }"
        )
        msg_box.exec()

def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion') # Sử dụng style Fusion để giao diện đồng bộ, sạch sẽ
    win = CaroWindow()
    win.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()